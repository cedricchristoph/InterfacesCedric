/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces_01.model.utils;

/**
 *
 * @author Cedric Christoph
 */
public class Strings {
    
    public static final String LABEL_APPLICATION_MENU = "Application Menu";
    public static final String BTN_AGREGAR_PERSONA = "Agregar Persona";
    public static final String BTN_EDITAR_PERSONA = "Modificar Persona";
    public static final String BTN_ELIMINAR_PERSONA = "Eliminar Persona";
    
}
