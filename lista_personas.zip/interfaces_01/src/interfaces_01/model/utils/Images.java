/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces_01.model.utils;

/**
 *
 * @author Cedric Christoph
 */
public class Images {
    
    public static final String ARROW_RIGHT = "/interfaces_01/res/arrow-24-256.png";
    public static final String ARROW_LEFT = "/interfaces_01/res/arrow-88-256.png";
    
}
